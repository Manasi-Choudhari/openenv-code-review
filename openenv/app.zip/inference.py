"""
Baseline inference script for the GitHub PR Code Review Environment.

Environment variables (MANDATORY — do not rename):
  API_BASE_URL       Base URL for the OpenAI-compatible API
  MODEL_NAME         Model identifier
  HF_TOKEN           API key / HuggingFace token
  LOCAL_IMAGE_NAME   (optional) Docker image name for local env hosting

Logging format (STRICT — do not change):
  [START] task=<task_name> env=<env_name> model=<model_name>
  [STEP]  step=<int> action=<string> reward=<float> done=<bool> error=<string_or_null>
  [END]   success=<bool> steps=<int> score=<float> rewards=<list>

Runtime target: < 20 minutes on CPU (2 vCPU, 8 GB RAM)
"""

from __future__ import annotations

import json
import os
import sys
import time
from typing import Any

from openai import OpenAI
from dotenv import load_dotenv
load_dotenv()

# ---------------------------------------------------------------------------
# Environment variables — EXACT names required by spec
# ---------------------------------------------------------------------------
API_BASE_URL = os.getenv("API_BASE_URL", "")
MODEL_NAME = os.getenv("MODEL_NAME", "")
HF_TOKEN = os.getenv("HF_TOKEN")
LOCAL_IMAGE_NAME = os.getenv("LOCAL_IMAGE_NAME")  # optional

# ---------------------------------------------------------------------------
# Validate required variables
# ---------------------------------------------------------------------------
if not API_BASE_URL:
    print("ERROR: API_BASE_URL environment variable is not set.", file=sys.stderr)
    sys.exit(1)
if not MODEL_NAME:
    print("ERROR: MODEL_NAME environment variable is not set.", file=sys.stderr)
    sys.exit(1)
if not HF_TOKEN:
    print("ERROR: HF_TOKEN environment variable is not set.", file=sys.stderr)
    sys.exit(1)

# ---------------------------------------------------------------------------
# OpenAI client — MANDATORY client configuration
# ---------------------------------------------------------------------------
client = OpenAI(
    base_url=API_BASE_URL,
    api_key=HF_TOKEN,
)

# ---------------------------------------------------------------------------
# Environment setup
# Supports two modes:
#   1. Direct Python import (default)
#   2. Docker image via LOCAL_IMAGE_NAME (uses HTTP transport to local container)
# ---------------------------------------------------------------------------

ENV_NAME = "PRReviewEnvironment"
TASKS = ["task1", "task2", "task3"]
MAX_STEPS_PER_TASK = 12      # hard cap per episode to stay under 20 min budget
REQUEST_TIMEOUT = 60          # seconds per LLM call


def _build_env_client(task_id: str):
    """
    Return an environment interface for the given task.
    If LOCAL_IMAGE_NAME is set, connects to a locally running Docker container
    via HTTP; otherwise uses the Python environment directly.
    """
    if LOCAL_IMAGE_NAME:
        # Docker-backed environment — connect to locally running container
        import requests  # type: ignore

        base = "http://localhost:7860"

        class DockerEnvClient:
            """Thin HTTP wrapper around the containerised environment."""

            def reset(self) -> dict[str, Any]:
                resp = requests.post(
                    f"{base}/reset",
                    json={"task_id": task_id},
                    timeout=30,
                )
                resp.raise_for_status()
                return resp.json()

            def step(self, action: dict[str, Any]) -> tuple[dict, dict, bool, dict]:
                resp = requests.post(
                    f"{base}/step",
                    json={"task_id": task_id, "action": action},
                    timeout=30,
                )
                resp.raise_for_status()
                data = resp.json()
                return data["observation"], data["reward"], data["done"], data["info"]

            def state(self) -> dict[str, Any]:
                resp = requests.get(
                    f"{base}/state",
                    params={"task_id": task_id},
                    timeout=30,
                )
                resp.raise_for_status()
                return resp.json()

        return DockerEnvClient()
    else:
        # Direct Python import
        from app.environment.env import PRReviewEnvironment
        from app.models.schemas import Action, IssueType

        class DirectEnvClient:
            """Wraps PRReviewEnvironment with a dict-based interface."""

            def __init__(self) -> None:
                self._env = PRReviewEnvironment(task_id=task_id)

            def reset(self) -> dict[str, Any]:
                obs = self._env.reset()
                return obs.model_dump()

            def step(self, action_dict: dict[str, Any]) -> tuple[dict, dict, bool, dict]:
                action = Action(**action_dict)
                obs, reward, done, info = self._env.step(action)
                return obs.model_dump(), reward.model_dump(), done, info

            def state(self) -> dict[str, Any]:
                return self._env.state().model_dump()

        return DirectEnvClient()


# ---------------------------------------------------------------------------
# Prompt builder
# ---------------------------------------------------------------------------

def _build_system_prompt() -> str:
    return (
        "You are an expert code reviewer. "
        "You will be shown a GitHub pull request with code diffs. "
        "Your job is to identify bugs, security vulnerabilities, logic errors, "
        "and performance issues. "
        "For each issue you find, respond ONLY with a valid JSON object in this exact format:\n"
        "{\n"
        '  "file": "<filename>",\n'
        '  "line": null,\n'
        '  "issue_type": "<bug|logic|performance|security|style|other>",\n'
        '  "comment": "<clear description of the issue>",\n'
        '  "suggestion": "<optional fix>",\n'
        '  "done": false\n'
        "}\n\n"
        'Set "done": true ONLY when you have found all issues and have nothing more to add. '
        "Do not include any text outside the JSON object."
    )


def _build_user_prompt(obs: dict[str, Any]) -> str:
    """Format the observation as a readable prompt for the LLM."""
    lines = [
        f"## PR: {obs['pr_title']}",
        f"{obs['pr_description']}",
        "",
        f"Step {obs['step_count']} of {obs['max_steps']}",
        "",
    ]

    for diff in obs.get("file_diffs", []):
        lines.append(f"### File: {diff['filename']} ({diff['language']})")
        lines.append("**After (new code):**")
        lines.append("```")
        lines.append(diff["after"])
        lines.append("```")
        lines.append("")

    prev = obs.get("previous_comments", [])
    if prev:
        lines.append("### Comments you have already made:")
        for c in prev:
            lines.append(f"- [{c['issue_type']}] {c['file']}: {c['comment']}")
        lines.append("")
        lines.append("Do NOT repeat any of the above. Find a NEW issue.")
    else:
        lines.append("No comments yet. Find the first issue.")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# LLM call with error handling
# ---------------------------------------------------------------------------

def _call_llm(messages: list[dict[str, str]]) -> str:
    """Call the LLM and return the raw text response."""
    response = client.chat.completions.create(
        model=MODEL_NAME,
        messages=messages,  # type: ignore[arg-type]
        max_tokens=512,
        temperature=0.0,    # deterministic / reproducible
        timeout=REQUEST_TIMEOUT,
    )
    return response.choices[0].message.content or ""


def _parse_action(raw: str) -> dict[str, Any]:
    """
    Parse the LLM output into an action dict.
    Falls back to a generic 'done' action on parse failure.
    """
    try:
        # Strip markdown fences if present
        text = raw.strip()
        if text.startswith("```"):
            text = "\n".join(text.split("\n")[1:])
            text = text.rstrip("`").strip()
        return json.loads(text)
    except (json.JSONDecodeError, ValueError):
        # Fallback: signal done to avoid infinite loop
        return {
            "file": "unknown",
            "line": None,
            "issue_type": "other",
            "comment": raw[:200] if raw else "No comment",
            "suggestion": None,
            "done": True,
        }


# ---------------------------------------------------------------------------
# Single-task episode runner
# ---------------------------------------------------------------------------

def run_task(task_id: str) -> dict[str, Any]:
    """
    Run one complete episode for the given task.
    Returns a summary dict with steps, score, and rewards.
    """
    env = _build_env_client(task_id)
    result = env.reset()
    obs = result["observation"]

    # ── [START] log ────────────────────────────────────────────────────────
    print(f"[START] task={task_id} env={ENV_NAME} model={MODEL_NAME}", flush=True)

    rewards: list[float] = []
    step_count = 0
    final_score = 0.0
    success = False
    done = False

    conversation: list[dict[str, str]] = [
        {"role": "system", "content": _build_system_prompt()},
    ]

    while not done and step_count < MAX_STEPS_PER_TASK:
        step_count += 1
        error_str = "null"
        action_str = ""
        reward_val = 0.0

        try:
            user_msg = _build_user_prompt(obs)
            conversation.append({"role": "user", "content": user_msg})

            raw_response = _call_llm(conversation)

            # Add assistant reply to history for multi-turn context
            conversation.append({"role": "assistant", "content": raw_response})

            action_dict = _parse_action(raw_response)
            action_str = action_dict.get("comment", "")[:120]

            obs, reward, done, info = env.step(action_dict)

            
            if isinstance(reward, dict):
                reward_val = reward.get("value", 0.0)
                cumulative_score = reward.get("cumulative_score", 0.0)
            else:
                reward_val = getattr(reward, "value", 0.0)
                cumulative_score = getattr(reward, "cumulative_score", 0.0)
            rewards.append(reward_val)

            if done:
                fs = info.get("final_score")
                if fs is not None:
                    final_score = float(fs)
                else:
                    # Compute from cumulative score
                    
                    final_score = float(cumulative_score)
                    
                success = True

        except Exception as exc:  # noqa: BLE001
            
            error_str = str(exc)[:200] if exc else "null"
            done = True  # abort episode on unexpected error
            success = False

        # ── [STEP] log ──────────────────────────────────────────────────────
        print(
            f"[STEP] step={step_count} action={action_str!r} "
            f"reward={reward_val} done={done} error={error_str}",
            flush=True,
        )

    # If we exited the loop due to MAX_STEPS guard (not env done), grab final score
    if not done:
        try:
            state = env.state()
            cs = state.get("final_score") if isinstance(state, dict) else state.final_score
            if cs is not None:
                final_score = float(cs)
        except Exception:  # noqa: BLE001
            pass

    # ── [END] log ───────────────────────────────────────────────────────────
    print(
        f"[END] success={success} steps={step_count} "
        f"score={final_score} rewards={rewards}",
        flush=True,
    )

    return {
        "task_id": task_id,
        "success": success,
        "steps": step_count,
        "score": final_score,
        "rewards": rewards,
    }


# ---------------------------------------------------------------------------
# Main — run all three tasks sequentially
# ---------------------------------------------------------------------------

def main() -> None:
    start_time = time.time()
    all_results: list[dict[str, Any]] = []

    for task_id in TASKS:
        result = run_task(task_id)
        all_results.append(result)

        elapsed = time.time() - start_time
        if elapsed > 18 * 60:
            # Safety guard: abort before 20-minute limit
            print(
                f"[WARN] Approaching 20-minute limit ({elapsed:.0f}s elapsed). "
                "Skipping remaining tasks.",
                file=sys.stderr,
                flush=True,
            )
            break

    # Print aggregate summary
    avg_score = sum(r["score"] for r in all_results) / max(len(all_results), 1)
    print(f"\n=== AGGREGATE RESULTS ===", flush=True)
    for r in all_results:
        print(
            f"  {r['task_id']}: score={r['score']:.3f} steps={r['steps']} success={r['success']}",
            flush=True,
        )
    print(f"  average_score={avg_score:.3f}", flush=True)
    print(f"  total_elapsed={time.time() - start_time:.1f}s", flush=True)


if __name__ == "__main__":
    main()
